#include"app.h"

int Start(void)
{
	ST_transaction_t transData;
	ST_cardData_t *cardData=&transData.cardHolderData;
	ST_terminalData_t *termData = &transData.terminalData;
	EN_cardError_t carderror;
	
	EN_terminalError_t termerror;
	EN_transState_t servererror;
	
	float maxAmount=0;

	carderror = getCardHolderName(cardData);
	if (carderror != 0)
		return carderror;
	carderror = getCardExpiryDate(cardData);
	if (carderror != 0)
		return carderror;
	carderror = getCardPAN(cardData);
	if (carderror != 0)
		return carderror;


	termerror = getTransactionDate(termData);
	if (termerror != 0)
		return termerror;
	termerror = isCardExpired(cardData,termData);
	if (termerror != 0)
		return termerror;
	termerror = getTransactionAmount(termData);
	if (termerror != 0)
		return termerror;
	termerror = setMaxAmount(termData, maxAmount);
	if (termerror != 0)
		return termerror;
	termerror = isBelowMaxAmount(termData);
	if (termerror != 0)
		return termerror;

	servererror = recieveTransactionData(&transData);
	if (servererror != 0) {
		listSavedTransactionsTest();
		return servererror;
	}
	listSavedTransactionsTest();
	return 0;
}