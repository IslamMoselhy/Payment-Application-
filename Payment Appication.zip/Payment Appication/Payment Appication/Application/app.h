
#pragma once
#ifndef App_H
#define App_H
#include "../Card/card.h"
#include "../Server/server.h"
#include "../Terminal/terminal.h"

int Start(void);
#endif