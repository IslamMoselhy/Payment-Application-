#include "card.h"


EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{
	printf("Enter card holder name \n");
	fgets(cardData->cardHolderName, 25, stdin);
	if ((strlen(cardData->cardHolderName)) > Maxname || (strlen(cardData->cardHolderName) < Minname))
	{
		printf("wrong name ! card holder name should be between 20 and 24 characters");
		return WRONG_NAME;
	}
	printf("the name you enter %s\n", cardData->cardHolderName);
	return OK_CARD;
}

EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData)
{
	printf("Enter card Expiary date in the format MM / YY\n" );
		fgets(cardData->cardExpirationDate, expiary_date_len +1, stdin);
		if (strlen(cardData->cardExpirationDate) != expiary_date_len) {
			printf("wrong Expiary Date\n ");
			return WRONG_EXP_DATE;	
		}
		else if (cardData->cardExpirationDate[2] != '/') {
			printf("wrong Expiary Date \n");
			return WRONG_EXP_DATE;
		}
		printf("the expiary date is %s\n", cardData->cardExpirationDate);
		int month_ED = (cardData->cardExpirationDate[0]-'0') * 10 + (cardData->cardExpirationDate[1]-'0');
		int year_ED = (cardData->cardExpirationDate[3] - '0') * 10 + (cardData->cardExpirationDate[4] - '0');
		printf("month_ED is %d\n", month_ED);
		printf("year_Ed is %d\n", year_ED);
		return OK_CARD;
}

EN_cardError_t getCardPAN(ST_cardData_t* cardData) {
	printf("please enter the pan\n");
	fgets(cardData->primaryAccountNumber, 20, stdin);
		if (strlen(cardData->primaryAccountNumber) < 16 ) {
			printf("wrong pan number\n");
			return WRONG_PAN;
		}
		else if (strlen(cardData->primaryAccountNumber) > 19) {
			printf("wrong pan number\n");
			return WRONG_PAN;
		}

		printf("pan number is %s\n", cardData->primaryAccountNumber);
		return OK_CARD;

}



