#ifndef CARD_H
#define CARD_H
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define Maxname 24
#define Minname 20
#define expiary_date_len 6
typedef unsigned char uint8_t;

typedef struct ST_cardData_t
{
	uint8_t cardHolderName[25];
	uint8_t primaryAccountNumber[20];
	uint8_t cardExpirationDate[7];
}ST_cardData_t;

typedef enum EN_cardError_t
{
	OK_CARD, WRONG_NAME, WRONG_EXP_DATE, WRONG_PAN
}EN_cardError_t;

EN_cardError_t getCardHolderName(ST_cardData_t* cardData);
EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData);
EN_cardError_t getCardPAN(ST_cardData_t* cardData);

#endif