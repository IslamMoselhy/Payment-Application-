#include "terminal.h"
EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{
	printf("please enter transaction Date in the format DD/MM/YYYY, e.g 25/06/2022.\n");
	fgets( termData->transactionDate, TRANSACTION_Date_LEN + 1, stdin);
	if (strlen(termData->transactionDate) != TRANSACTION_Date_LEN) {
		printf("wrong Transaction Date\n");
		return WRONG_DATE;
	}
	else if (termData->transactionDate[2] != '/') {
		printf("wrong Transaction Date\n");
		return WRONG_DATE;
	}
	else if (termData->transactionDate[5] != '/') {
		printf("wrong Transaction Date\n");
		return WRONG_DATE;
	}
	printf("Card transaction date is %s\n",termData->transactionDate);
	
	
		
		int month_TD = (termData->transactionDate[3] - '0') * 10 + (termData->transactionDate[4] - '0');
		int year_TD = (termData->transactionDate[8] - '0') * 10 + (termData->transactionDate[9] - '0');
		printf("month_TD is %d\n", month_TD);
		printf("year_TD is %d\n", year_TD);
		return TERMINAL_OK;
		;
}

EN_terminalError_t isCardExpired(ST_cardData_t* cardData, ST_terminalData_t* termData) {
	int month_ED = (cardData->cardExpirationDate[0] - '0') * 10 + (cardData->cardExpirationDate[1] - '0');
	int year_ED = (cardData->cardExpirationDate[3] - '0') * 10 + (cardData->cardExpirationDate[4] - '0');
	int month_TD = (termData->transactionDate[3] - '0') * 10 + (termData->transactionDate[4] - '0');
	int year_TD = (termData->transactionDate[8] - '0') * 10 + (termData->transactionDate[9] - '0');
	if (year_ED > year_TD) {
		printf("card is up to date\n");
		return TERMINAL_OK;
	}
	else if (year_TD == year_ED && month_ED >= month_TD) {
		printf("card is up to date\n");
		return TERMINAL_OK;
	}
	else if (year_TD == year_ED && month_ED < month_TD) {
		printf("Decline error:card is Expired\n");
		return EXPIRED_CARD;
	}
	else if (year_ED<year_TD||(year_ED == year_ED && month_ED < month_TD))
		printf("Decline error:card is Expired\n");
	    return EXPIRED_CARD;
}

EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData) {
	printf("please enter transaction amount\n");
	scanf_s("%f", &termData->transAmount);
	if (termData->transAmount <= 0)
	{
		printf("INVALID transaction AMOUNT\n");
		return INVALID_AMOUNT;
	}
	return TERMINAL_OK;
}

EN_terminalError_t setMaxAmount(ST_terminalData_t* termData)
{
	printf("please Enter MAX amount of the terminal: ");
	scanf_s("%f", &termData->maxTransAmount);
	if (termData->maxTransAmount <= 0)
	{
		printf("INVALID MAX AMOUNT\n");
		return INVALID_MAX_AMOUNT;
	}
	return TERMINAL_OK;
}

EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	if (termData->transAmount > termData->maxTransAmount)
	{
		printf("transaction declined error:EXCEED MAX AMOUNT\n");
		return EXCEED_MAX_AMOUNT;
	}
	return TERMINAL_OK;
}