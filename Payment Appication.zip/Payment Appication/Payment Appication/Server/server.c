#include "Server.h"

ST_accountsDB_t current_Card;
int card_index = 0;
uint32_t sequence = 0,sequence_no = 0;

extern ST_accountsDB_t serverDatabase[MAX_SERVER] = {
	{3000.0,RUNNING, "1234567890987654"},
	{5000.7,BLOCKED, "2345678909876543"},
	{10000.5,RUNNING, "3456789098765432"},
	{12000.3, RUNNING,"4567890987654321"},
	{11000.44,BLOCKED, "5678909876543212"},
	{13500.2,RUNNING, "6789098765432123"},
	{1530.8, RUNNING,"7890987654321234"},
	{17650.0,RUNNING, "8909876543212345"},
	{100000.5,BLOCKED, "9098765432123456"},
	{1920.3,BLOCKED, "0987654321234567"},
};

extern ST_transaction_t transactionDatabase[MAX_TRANSACTION] = { 0 };


FILE* databaseFilePtr;
uint8_t  i;


EN_transState_t recieveTransactionData(ST_transaction_t * transData) {

	if ((databaseFilePtr = fopen("Server/database file.dat", "r+")) == NULL) {
		printf("Declined error:Internal server error\n");
		return 0;
		
	}
	i = fwrite(&serverDatabase, sizeof(ST_accountsDB_t), 10, databaseFilePtr);
	fclose(databaseFilePtr);

	EN_serverError_t server_error;
	if( isValidAccount(&transData->cardHolderData)){
		printf("Fraud card\n");
		transactionDatabase[sequence_no].transState = FRAUD_CARD;
		saveTransaction(transData);
		return FRAUD_CARD;

	}

	else if (isBlockedAccount(&current_Card)) {
		printf("Declined Stolen Card\n");
		transactionDatabase[sequence_no].transState = DECLINED_STOLEN_CARD;
		saveTransaction(transData);
		return DECLINED_STOLEN_CARD;
	}
	

	else if (isAmountAvailable(&transData->terminalData, &current_Card)) {
		printf("declined insufficient funds\n");
		transactionDatabase[sequence_no].transState = DECLINED_INSUFFECIENT_FUND;
		saveTransaction(transData);
		return DECLINED_INSUFFECIENT_FUND;
   }
	else { 
		printf("Approved\n");
		transactionDatabase[sequence_no].transState = APPROVED;
		saveTransaction(transData);
	}

}


EN_serverError_t isValidAccount(ST_cardData_t* cardData) {
	ST_accountsDB_t temp;

	if ((databaseFilePtr = fopen("Server/database file.dat", "rb")) == NULL) {
		return ACCOUNT_NOT_FOUND;
	}
	cardData->primaryAccountNumber[strcspn(cardData->primaryAccountNumber, "\n")] = 0;
	while (!feof(databaseFilePtr)) {
		i = fread(&temp, sizeof(ST_accountsDB_t), 1, databaseFilePtr);

		if (i == 0 || temp.primaryAccountNumber[0] == '\0') {
			printf("Account not found\n");
			return ACCOUNT_NOT_FOUND;
		}

		if (strcmp(temp.primaryAccountNumber, cardData->primaryAccountNumber) == 0) {
			current_Card = temp;
			fclose(databaseFilePtr);
			printf("pan no. found\n");
			return OK;
		}
		card_index++;
	}
		printf("card fraud pan no. not found\n");
		return ACCOUNT_NOT_FOUND;
	
}

EN_serverError_t isBlockedAccount(ST_accountsDB_t* accountRefrence) {
	if (accountRefrence->state) {
		printf("this card is blocked\n");
		return Blocked_Account;
	}
	printf("card is running\n");
	return OK;
}



EN_serverError_t isAmountAvailable(ST_terminalData_t* termData, ST_accountsDB_t* accountRefrence) {
	if (termData->transAmount > accountRefrence->balance) {
		printf("low balance\n");
		return LOW_BALANCE;

	}
	else {
		printf("amount is available\n");
		//new
		float current_balance = accountRefrence->balance - termData->transAmount;
		printf("your current balance is %.1f\n", current_balance);
		//
		return OK;
	}
	
}

EN_serverError_t saveTransaction(ST_transaction_t* transData) {
	if (sequence_no > MAX_TRANSACTION) {
		printf("Declined error:INTERNAL_SERVER_ERROR");
		return INTERNAL_SERVER_ERROR;
	}
	transactionDatabase[sequence_no].transactionSequenceNumber = sequence_no;
	transactionDatabase[sequence_no].cardHolderData = transData->cardHolderData;
	transactionDatabase[sequence_no].terminalData = transData->terminalData;
	sequence_no++;
}


void listSavedTransactionsTest(void) {
	sequence = sequence_no - 1;
	printf("########################################################\n");
	printf("Transaction sequence number: %d \n", sequence_no);
	printf("Transaction Date: %s\n", transactionDatabase[sequence].terminalData.transactionDate);
	printf("Transaction Amount:%.1f\n", transactionDatabase[sequence].terminalData.transAmount);
	if (transactionDatabase[sequence].transState == 0)
		printf("transaction approved\n");
	else if (transactionDatabase[sequence].transState == 1)
		printf("Declined insuffecient funds\n");
	else if (transactionDatabase[sequence].transState == 2)
		printf("Declined stolen card\n");
	else if (transactionDatabase[sequence].transState == 3)
		printf("Fraud Card\n");
	else if (transactionDatabase[sequence].transState == 4)
		printf("internal server error\n");
	
	printf("Terminal max allowed amount:%.1f\n", transactionDatabase[sequence].terminalData.maxTransAmount);
	printf("card holder name:%s\n", transactionDatabase[sequence].cardHolderData.cardHolderName);
	printf("Pan no.:%s\n",transactionDatabase[sequence].cardHolderData.primaryAccountNumber);
	printf("Card Expiration date:%s\n", transactionDatabase[sequence].cardHolderData.cardExpirationDate);
	printf("########################################################\n");

}